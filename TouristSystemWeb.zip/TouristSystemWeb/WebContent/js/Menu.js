/**
 * 
 */
function TourOver(){
	var tour = document.getElementById("Tour");
	tour.src="image/Tour3.png";
}

function TourOut(){
	var tour = document.getElementById("Tour");
	
	tour.src="image/Tour.png";
}

function AdminOver(){
	var Admin = document.getElementById("Admin");
	Admin.src="image/Admin2.jpg";
}

function AdminOut(){
	var Admin = document.getElementById("Admin");
	
	Admin.src="image/Admin.jpg";
}



